var AppAssessmentConfig = (function() {
    return {
        VENDOR_SCHOOL_ID_TYPE: "",
        VENDOR_NAME : "ACADIENCE",
        PRODUCT_NAME: "ACADIENCE",
        CONNECTOR_NAME: "vendor.acadience.ACADIENCE",
        PRODUCT_LIST: [
            {
                UI_DISPLAY_NAME: "Acadience",
                VENDOR_FOLDER_NAME: "ACADIENCE",
                PRODUCT_FOLDER_NAME: "ACADIENCE",
                PERIODS:  ["ALL", "Beginning", "Middle", "End"],
                SIGNATURES: [
                    {
                         YEARS: ["2017-2018","2018-2019","2019-2020","2020-2021","2021-2022","2022-2023","2023-2024","2024-2025","*"],
                         SIGNATURE_FILE: "ACADIENCE_214_COLS.sig",
                         CLIENT_CODE: ["ALL"]
                    },
                    {
                         YEARS: ["2017-2018","2018-2019","2019-2020","2020-2021","2021-2022","2022-2023","2023-2024","2024-2025","*"],
                         SIGNATURE_FILE: "ACADIENCE_72_COLS.sig",
                         CLIENT_CODE: ["ALL"]
                    }
                ]
            }
        ]
    }
}());
